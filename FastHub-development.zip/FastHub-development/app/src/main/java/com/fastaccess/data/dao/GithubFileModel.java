package com.fastaccess.data.dao;

import java.io.Serializable;
import java.util.HashMap;

/**
 * Created by Kosh on 10 Feb 2017, 9:46 PM
 */


public class GithubFileModel extends HashMap<String, FilesListModel> implements Serializable {}