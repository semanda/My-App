package com.fastaccess.data.dao.types;

public enum GitEntryType {
    commit,
    tree,
    blob
}