package com.fastaccess.ui.modules.gists.create.dialog

import com.fastaccess.ui.base.mvp.presenter.BasePresenter

/**
 * Created by kosh on 14/08/2017.
 */
class AddGistPresenter : BasePresenter<AddGistMvp.View>(), AddGistMvp.Presenter