package com.fastaccess.data.dao.types;

/**
 * Created by Kosh on 30 Apr 2017, 1:03 PM
 */

public enum MyIssuesType {
    CREATED,
    ASSIGNED,
    MENTIONED,
    REVIEW,
    PARTICIPATED
}
